package com.example.demo.model.other;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Folder {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long fileId;

	@Column(unique = true)
	private String folderName;
	private String owner;
	private String description;

	private Timestamp dateUploaded;
	private Timestamp lastAccessed;
}
