package com.example.demo.model.other;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class File {
	 	@Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long fileId;

	    @Column(unique = true)
	    private String filename;
	    private String owner;
	    private String extension;
	    private String description;

	    private Timestamp dateUploaded;
	    private Timestamp lastAccessed;
}
