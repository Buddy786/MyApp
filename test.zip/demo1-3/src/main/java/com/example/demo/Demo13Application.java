package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo13Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo13Application.class, args);
	}

}
